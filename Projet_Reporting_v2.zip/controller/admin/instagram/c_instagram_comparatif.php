<?php

    /* Dependance de la page */
    include 'model/m_pagesInsta.php';
    include 'model/m_compteFB.php';

    /* Preparation de la page */
    $listePageInsta = getPagesInsta_BDD();
?>