<?php

    /* Dependance de la page */
    include 'model/m_pagesFB.php';
    include 'model/m_compteFB.php';

    $listePageFB = getPagesFB_BDD();
?>