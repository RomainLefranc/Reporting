
<?php
include 'model/m_pagesInsta.php';
include 'model/m_pagesFB.php';

$listePagesInsta = getPagesInsta_BDD();
$listePagesFB = getPagesFB_BDD();

?>
