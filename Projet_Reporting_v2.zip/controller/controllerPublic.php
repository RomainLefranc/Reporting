<?php
    include 'public/'.$controller.'.php';
?>