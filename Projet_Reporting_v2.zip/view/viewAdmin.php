<?php

    include 'admin/'.$view.'.php';

?>