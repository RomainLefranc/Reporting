<?php
    include 'public/'.$view.'.php';
?>