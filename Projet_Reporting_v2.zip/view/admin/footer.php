<div id="fb-root"></div>
<script>
  window.fbAsyncInit = function() {
    FB.init({
      appId            : '941052469578811',
      autoLogAppEvents : true,
      xfbml            : true,
      version          : 'v4.0'
    });
  };
</script>
<script async defer crossorigin="anonymous" src="https://connect.facebook.net/fr_FR/sdk.js#xfbml=1&version=v4.0&appId=941052469578811&autoLogAppEvents=1"></script>